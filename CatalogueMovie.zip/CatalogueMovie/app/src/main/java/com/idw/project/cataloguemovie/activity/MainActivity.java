package com.idw.project.cataloguemovie.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.idw.project.cataloguemovie.R;
import com.idw.project.cataloguemovie.fragment.FavoriteFragment;
import com.idw.project.cataloguemovie.fragment.MovieFragment;
import com.idw.project.cataloguemovie.fragment.SettingsFragment;
import com.idw.project.cataloguemovie.fragment.TvShowFragment;
import com.luseen.spacenavigation.SpaceItem;
import com.luseen.spacenavigation.SpaceNavigationView;
import com.luseen.spacenavigation.SpaceOnClickListener;

public class MainActivity extends AppCompatActivity {
    SpaceNavigationView navigationView;
    Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            Window w = getWindow();
//            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
//        }

        navigationView = findViewById(R.id.space);

        navigationView.initWithSaveInstanceState(savedInstanceState);
        navigationView.addSpaceItem(new SpaceItem("Beranda", R.drawable.ic_movie_black_24dp));
        navigationView.addSpaceItem(new SpaceItem("Riwayat", R.drawable.ic_tv_black_24dp));
        navigationView.addSpaceItem(new SpaceItem("Live Chat", R.drawable.ic_settings_black_24dp));
        navigationView.addSpaceItem(new SpaceItem("Bantuan", R.drawable.ic_settings_black_24dp));

        navigationView.showIconOnly();
        navigationView.setActiveSpaceItemColor(ContextCompat.getColor(this, R.color.colorPrimary));
        navigationView.setCentreButtonColor(ContextCompat.getColor(this, R.color.colorPrimary));
        navigationView.setCentreButtonRippleColor(ContextCompat.getColor(this, R.color.colorPrimary));
        navigationView.setCentreButtonIcon(R.drawable.ic_favorite_black_24dp);

        navigationView.setSpaceOnClickListener(new SpaceOnClickListener() {
            @Override
            public void onCentreButtonClick() {
                Toast.makeText(MainActivity.this,"onCentreButtonClick", Toast.LENGTH_SHORT).show();
                navigationView.setCentreButtonSelectable(true);
                fragment = new FavoriteFragment();
                loadFragment(fragment);
            }

            @Override
            public void onItemClick(int itemIndex, String itemName) {
//                Toast.makeText(MainActivity.this, itemIndex + " " + itemName, Toast.LENGTH_SHORT).show();
                switch (itemIndex){
                    case 0:
                        Toast.makeText(MainActivity.this, "Galau", Toast.LENGTH_SHORT).show();
                        fragment = new MovieFragment();
                        loadFragment(fragment);
                        break;
                    case 1:
                        Toast.makeText(MainActivity.this, "Sangat", Toast.LENGTH_SHORT).show();
                        fragment = new TvShowFragment();
                        loadFragment(fragment);
                        break;
                    case 2:
                        Toast.makeText(MainActivity.this, "Makan", Toast.LENGTH_SHORT).show();
                        fragment = new TvShowFragment();
                        loadFragment(fragment);
                        break;
                    case 3:
                        Toast.makeText(MainActivity.this, "Hai", Toast.LENGTH_SHORT).show();
                        fragment = new SettingsFragment();
                        loadFragment(fragment);
                        break;
                }
            }

            @Override
            public void onItemReselected(int itemIndex, String itemName) {
                switch (itemIndex){
                    case 0:
                        Toast.makeText(MainActivity.this, "Galau", Toast.LENGTH_SHORT).show();
                        fragment = new MovieFragment();
                        loadFragment(fragment);
                        break;
                    case 1:
                        Toast.makeText(MainActivity.this, "Sangat", Toast.LENGTH_SHORT).show();
                        fragment = new TvShowFragment();
                        loadFragment(fragment);
                        break;
                    case 2:
                        Toast.makeText(MainActivity.this, "Makan", Toast.LENGTH_SHORT).show();
                        fragment = new TvShowFragment();
                        loadFragment(fragment);
                        break;
                    case 3:
                        Toast.makeText(MainActivity.this, "Hai", Toast.LENGTH_SHORT).show();
                        fragment = new SettingsFragment();
                        loadFragment(fragment);
                        break;
                }
            }

        });

        if (savedInstanceState == null){
            fragment = new MovieFragment();
            loadFragment(fragment);
        }else {
            Log.d(String.valueOf(getApplicationContext()), "cek");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        navigationView.onSaveInstanceState(outState);
    }


    private void loadFragment(Fragment fragment) {
        // load fragment
//        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.btt, R.anim.fade_out);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
