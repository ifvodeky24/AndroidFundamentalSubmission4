package com.idw.project.cataloguemovie.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.idw.project.cataloguemovie.R;
import com.idw.project.cataloguemovie.config.Config;
import com.idw.project.cataloguemovie.model.Movie;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class FavoriteMovieAdapter extends RecyclerView.Adapter<FavoriteMovieAdapter.FavoriteMovieViewholder> {
    private Context context;

    private ArrayList<Movie> dataList;
    private final MovieAdapter.OnItemClickListener listener;

    public FavoriteMovieAdapter(Context context, ArrayList<Movie> dataList, MovieAdapter.OnItemClickListener listener) {
        this.context = context;
        this.dataList = dataList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FavoriteMovieViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_item, parent,
                false);

        return new FavoriteMovieViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteMovieViewholder favoriteMovieViewholder, int position) {
        favoriteMovieViewholder.bind(dataList.get(position), listener);

    }

    @Override
    public int getItemCount() {
        return (dataList != null) ? dataList.size() :0;
    }

    public class FavoriteMovieViewholder extends RecyclerView.ViewHolder{
        ImageView iv_poster_movie;
        TextView tv_title_movie, tv_release_date_movie, tv_description_movie, tv_rb_movie;
        CardView cv_movie;
        RatingBar rb_movie;

        public FavoriteMovieViewholder(@NonNull View itemView) {
            super(itemView);
            iv_poster_movie = itemView.findViewById(R.id.iv_poster_movie);
            tv_title_movie = itemView.findViewById(R.id.tv_title_movie);
            tv_release_date_movie = itemView.findViewById(R.id.tv_release_date_movie);
            rb_movie = itemView.findViewById(R.id.rb_movie);
            tv_rb_movie = itemView.findViewById(R.id.tv_rb_movie);
            tv_description_movie = itemView.findViewById(R.id.tv_description_movie);
            cv_movie = itemView.findViewById(R.id.cv_movie);
        }

        public void bind(final Movie item, final MovieAdapter.OnItemClickListener listener){
            tv_title_movie.setText(item.getTitle());
            tv_release_date_movie.setText("Rilis: "+item.getReleaseDate());
            tv_description_movie.setText(item.getOverview());
            tv_rb_movie.setText(String.valueOf(item.getVoteAverage()));
            rb_movie.setRating(Float.parseFloat(String.valueOf(item.getVoteAverage())));

            Picasso.with(itemView.getContext())
                    .load(Config.IMAGE_W342+item.getPosterPath())
                    .fit()
                    .centerCrop()
                    .into(iv_poster_movie);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(item);
                }
            });
        }
    }

}
