package com.idw.project.cataloguemovie.db;

import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public class DatabaseContract {

    public static String TABLE_FAVORITE = "favorite";

    public static final class MovieColumn implements BaseColumns {
        public static String TITLE = "title";
        public static String OVERVIEW = "overview";
        public static String POSTER_PATH = "poster_path";
    }

    public static final String AUTHORITY = "com.idw.project.cataloguemovie";

    public static final Uri CONTENT_URI = new Uri.Builder().scheme("content")
            .authority(AUTHORITY)
            .appendPath(TABLE_FAVORITE)
            .build();

    public static String getColumnString(Cursor cursor, String columnName) {
        return cursor.getString(cursor.getColumnIndex(columnName));
    }

    public static int getColumnInt(Cursor cursor, String columnName) {
        return cursor.getInt(cursor.getColumnIndex(columnName));
    }

    public static long getColumnLong(Cursor cursor, String columName) {
        return cursor.getLong(cursor.getColumnIndex(columName));
    }


}
