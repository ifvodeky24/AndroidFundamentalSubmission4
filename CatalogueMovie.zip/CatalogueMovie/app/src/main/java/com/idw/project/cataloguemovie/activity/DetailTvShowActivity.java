package com.idw.project.cataloguemovie.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.idw.project.cataloguemovie.MainViewModel;
import com.idw.project.cataloguemovie.R;
import com.idw.project.cataloguemovie.config.Config;
import com.idw.project.cataloguemovie.model.Genre;
import com.idw.project.cataloguemovie.model.TvShow;
import com.idw.project.cataloguemovie.response.ResponseTvShowDetail;
import com.idw.project.cataloguemovie.rest.ApiClient;
import com.idw.project.cataloguemovie.rest.ApiInterface;
import com.squareup.picasso.Picasso;

import java.util.List;

import jp.wasabeef.picasso.transformations.BlurTransformation;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailTvShowActivity extends AppCompatActivity {

    public static final String TAG = "tv";
    Integer id;
    String genre, title, tv_rb, tv_release_date_string, tv_description_string;
    float rb;

    ApiInterface apiService;

    ImageView iv_poster_tv, iv_poster_tv_front;
    TextView tv_title_tv_detail, tv_rb_tv, tv_genre, tv_release_date, tv_description;
    RatingBar rb_tv;

    private static final String API_KEY= Config.API_KEY;

    private MainViewModel mainViewModel;

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv_show);

        apiService = ApiClient.getClient().create(ApiInterface.class);

        final TvShow tvShow = getIntent().getExtras().getParcelable(TAG);

        System.out.println("id nya sekarang"+ tvShow.getId());
        System.out.println("judul nya adalah"+ tvShow.getName());
        System.out.println("tanggal rilisnya nya adalah"+ tvShow.getFirstAirDate());
        System.out.println("deskripsi nya adalah"+ tvShow.getOverview());

        iv_poster_tv = findViewById(R.id.iv_poster_tv);
        iv_poster_tv_front = findViewById(R.id.iv_poster_tv_front);
        tv_title_tv_detail = findViewById(R.id.tv_title_tv_detail);
        tv_genre = findViewById(R.id.tv_genre);
        tv_release_date = findViewById(R.id.tv_release_date);
        tv_description = findViewById(R.id.tv_description);
        tv_rb_tv = findViewById(R.id.tv_rb_tv);
        rb_tv = findViewById(R.id.rb_tv);
        webView = findViewById(R.id.mWebView);

        //get Id
        id = tvShow.getId();

        System.out.println("id now"+id);

        iv_poster_tv_front.bringToFront();

        apiService.getTvDetails(id, API_KEY).enqueue(new Callback<ResponseTvShowDetail>() {
            @Override
            public void onResponse(Call<ResponseTvShowDetail> call, Response<ResponseTvShowDetail> response) {
                System.out.println("response detail"+response);
                if (response.isSuccessful()){
                    List<Genre> genres = response.body().getGenres();
                    genre = String.valueOf(genres.get(0).getName());
                    System.out.println("genre"+genre);

                    tv_genre.setText(genre);

                }else {
                    Toast.makeText(getApplicationContext(), "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<ResponseTvShowDetail> call, Throwable t) {
                t.printStackTrace();
            }
        });

        title = tvShow.getOriginalName();
        rb = Float.parseFloat(String.valueOf(tvShow.getVoteAverage()));
        tv_rb = String.valueOf(tvShow.getVoteAverage());
        tv_release_date_string = tvShow.getFirstAirDate();
        tv_description_string = tvShow.getOverview();

        tv_title_tv_detail.setText(title);
        rb_tv.setRating(rb);
        tv_rb_tv.setText(tv_rb);
        tv_release_date.setText(tv_release_date_string);
        tv_description.setText(tv_description_string);
        Picasso.with(DetailTvShowActivity.this)
                .load(Config.IMAGE_W500+tvShow.getBackdropPath())
                .transform(new BlurTransformation(getApplicationContext(), 5,1))
                .fit()
                .centerCrop()
                .into(iv_poster_tv);

        Picasso.with(DetailTvShowActivity.this)
                .load(Config.IMAGE_W500+tvShow.getPosterPath())
                .fit()
                .centerCrop()
                .into(iv_poster_tv_front);

        mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.getListTvVideos(String.valueOf(id)).observe(this, getListTvVideo);
    }

    private Observer<String> getListTvVideo = new Observer<String>() {
        @Override
        public void onChanged(String tvs) {
            if (tvs != null){

                String frameVideo = "<html><body>Video From YouTube<br><iframe width=\"320\" height=\"250\" frameborder=\"0\" allowfullscreen></iframe></body></html>";

                System.out.println("cekPath11"+tvs);

                webView.setVisibility(View.VISIBLE);

                webView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        return false;
                    }
                });

                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadData(frameVideo, "text/html", "utf-8");
                webView.loadUrl(tvs);
            }else {
                webView.setVisibility(View.INVISIBLE);
                webView.setVisibility(View.GONE);
            }
        }
    };
}
